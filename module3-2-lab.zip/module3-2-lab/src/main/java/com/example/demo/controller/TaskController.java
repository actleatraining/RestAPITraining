package com.example.demo.controller;

import com.example.demo.model.Task;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private List<Task> tasks = new ArrayList<>();
    private int nextId = 1;

    public TaskController() {
        tasks.add(new Task(nextId++, "Buy groceries", false));
        tasks.add(new Task(nextId++, "Study Spring Boot", false));
    }

    @GetMapping
    public List<Task> getAll() {
        return tasks;
    }

    @GetMapping("/{id}")
    public Task getOne(@PathVariable int id) {
        return tasks.stream()
                .filter(t -> t.getId() == id)
                .findFirst()
                .orElse(null);
    }

    @PostMapping
    public Task create(@RequestBody Task taskRequest) {
        Task task = new Task(nextId++, taskRequest.getTitle(), false);
        tasks.add(task);
        return task;
    }

    @PatchMapping("/{id}/toggle")
    public Task toggle(@PathVariable int id) {
        Task t = tasks.stream()
                .filter(x -> x.getId() == id)
                .findFirst()
                .orElse(null);

        if (t != null) {
            t.setCompleted(!t.isCompleted());
        }

        return t;
    }
}
