package com.resort.beachactivity;

import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class BeachActivityApplicationTests {

    @LocalServerPort
    private int port;

    @BeforeEach
    void setup() {
        RestAssured.port = port;
    }

    // ------------------------------------------------------------
    // 1. GET /activities — Validate nested structure
    // ------------------------------------------------------------
    @Test
    void testGetAllActivitiesValidateNestedBookings() {
        given()
                .when()
                .get("/activities")
                .then()
                .statusCode(200)
                .body("$", hasSize(greaterThanOrEqualTo(6)))

                // Validate first activity
                .body("[0].name", equalTo("Snorkeling Adventure"))
                .body("[0].category", equalTo("Water Sports"))
                .body("[0].price", equalTo(45.0f))
                .body("[0].durationMinutes", equalTo(90))

                // Validate nested bookings exist
                .body("[0].bookings.size()", equalTo(2))
                .body("[0].bookings[0].guestName", equalTo("Sophia Wave"))
                .body("[0].bookings[1].numParticipants", equalTo(4))

                // Validate second activity has exactly one booking
                .body("[1].name", equalTo("Sunset Yoga"))
                .body("[1].bookings.size()", equalTo(1));
    }

    // ------------------------------------------------------------
    // 2. GET /activities/{id} — Extract deep nested data
    // ------------------------------------------------------------
    @Test
    void testGetActivityById() {
        int id =
                given().get("/activities")
                        .then().extract().path("[0].id");

        given()
                .when()
                .get("/activities/" + id)
                .then()
                .statusCode(200)
                .body("name", equalTo("Snorkeling Adventure"))
                .body("bookings.size()", equalTo(2))
                .body("bookings.guestName", hasItem("Sophia Wave"));
    }

    // ------------------------------------------------------------
    // 3. POST /activities — Create new activity
    // ------------------------------------------------------------
    @Test
    void testCreateActivity() {

        int newId =
                given()
                        .contentType("application/json")
                        .body("""
                        {
                          "name": "Beach Meditation",
                          "category": "Wellness",
                          "price": 25,
                          "durationMinutes": 50
                        }
                        """)
                        .when()
                        .post("/activities")
                        .then()
                        .statusCode(200)
                        .body("name", equalTo("Beach Meditation"))
                        .extract()
                        .path("id");

        // Confirm it exists
        given()
                .when()
                .get("/activities/" + newId)
                .then()
                .statusCode(200)
                .body("category", equalTo("Wellness"))
                .body("bookings", hasSize(0));
    }

    // ------------------------------------------------------------
    // 4. PUT /activities/{id} — Update existing activity
    // ------------------------------------------------------------
    @Test
    void testUpdateActivity() {
        // Create first
        int id =
                given()
                        .contentType("application/json")
                        .body("""
                        {
                          "name": "Kayak Tour",
                          "category": "Water Sports",
                          "price": 50,
                          "durationMinutes": 80
                        }
                        """)
                        .when()
                        .post("/activities")
                        .then()
                        .extract()
                        .path("id");

        // Then update
        given()
                .contentType("application/json")
                .body("""
                {
                  "name": "Updated Kayak Tour",
                  "category": "Water Sports",
                  "price": 55,
                  "durationMinutes": 90
                }
                """)
                .when()
                .put("/activities/" + id)
                .then()
                .statusCode(200)
                .body("name", equalTo("Updated Kayak Tour"))
                .body("price", equalTo(55));
    }

    // ------------------------------------------------------------
    // 5. DELETE /activities/{id} — Full delete flow
    // ------------------------------------------------------------
    @Test
    void testDeleteActivity() {
        int id =
                given()
                        .contentType("application/json")
                        .body("""
                        {
                          "name": "Temporary Activity",
                          "category": "Test",
                          "price": 10,
                          "durationMinutes": 10
                        }
                        """)
                        .post("/activities")
                        .then()
                        .extract()
                        .path("id");

        // Delete
        given()
                .when()
                .delete("/activities/" + id)
                .then()
                .statusCode(200);

        // Confirm gone
        given()
                .when()
                .get("/activities/" + id)
                .then()
                .statusCode(500);  // Matches your API behavior
    }

    // ------------------------------------------------------------
    // 6. POST /bookings/activity/{activityId} — Add booking
    // ------------------------------------------------------------
    @Test
    void testAddBookingToActivity() {
        // Create activity
        int activityId =
                given()
                        .contentType("application/json")
                        .body("""
                        {
                          "name": "Test Booking Activity",
                          "category": "Demo",
                          "price": 100,
                          "durationMinutes": 120
                        }
                        """)
                        .post("/activities")
                        .then()
                        .extract()
                        .path("id");

        // Add booking
        int bookingId =
                given()
                        .contentType("application/json")
                        .body("""
                        {
                          "guestName": "Test Guest",
                          "activityDate": "2025-11-20",
                          "numParticipants": 3
                        }
                        """)
                        .when()
                        .post("/bookings/activity/" + activityId)
                        .then()
                        .statusCode(200)
                        .body("guestName", equalTo("Test Guest"))
                        .extract()
                        .path("id");

        // Verify booking appears under the activity
        given()
                .when()
                .get("/activities/" + activityId)
                .then()
                .statusCode(200)
                .body("bookings.guestName", hasItem("Test Guest"))
                .body("bookings[0].numParticipants", equalTo(3));
    }

    // ------------------------------------------------------------
    // 7. GET /bookings — Validate booking list
    // ------------------------------------------------------------
    @Test
    void testGetAllBookings() {
        given()
                .when()
                .get("/bookings")
                .then()
                .statusCode(200)
                .body("$", hasSize(greaterThanOrEqualTo(4)))
                .body("[0].guestName", notNullValue())
                .body("[0].activityDate", matchesRegex("\\d{4}-\\d{2}-\\d{2}"));
    }

    // ------------------------------------------------------------
    // 8. GET /bookings/{id} — Basic read
    // ------------------------------------------------------------
    @Test
    void testGetBookingById() {
        int id =
                given().get("/bookings")
                        .then().extract().path("[0].id");

        given()
                .when()
                .get("/bookings/" + id)
                .then()
                .statusCode(200)
                .body("guestName", notNullValue())
                .body("numParticipants", greaterThanOrEqualTo(1));
    }
}