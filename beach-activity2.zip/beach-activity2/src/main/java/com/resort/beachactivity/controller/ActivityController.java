package com.resort.beachactivity.controller;

import com.resort.beachactivity.entity.Activity;
import com.resort.beachactivity.repository.ActivityRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/activities")
public class ActivityController {

    private final ActivityRepository activityRepository;

    public ActivityController(ActivityRepository activityRepository) {
        this.activityRepository = activityRepository;
    }

    @GetMapping
    public List<Activity> getAllActivities() {
        return activityRepository.findAll();
    }

    @GetMapping("/{id}")
    public Activity getActivityById(@PathVariable Long id) {
        return activityRepository.findById(id).orElseThrow();
    }

    @PostMapping
    public Activity createActivity(@RequestBody Activity activity) {
        return activityRepository.save(activity);
    }

    @PutMapping("/{id}")
    public Activity updateActivity(@PathVariable Long id, @RequestBody Activity activity) {
        Activity existing = activityRepository.findById(id).orElseThrow();
        existing.setName(activity.getName());
        existing.setCategory(activity.getCategory());
        existing.setPrice(activity.getPrice());
        existing.setDurationMinutes(activity.getDurationMinutes());
        return activityRepository.save(existing);
    }

    @DeleteMapping("/{id}")
    public void deleteActivity(@PathVariable Long id) {
        activityRepository.deleteById(id);
    }
}
