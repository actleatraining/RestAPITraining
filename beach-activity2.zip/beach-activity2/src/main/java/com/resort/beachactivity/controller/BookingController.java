package com.resort.beachactivity.controller;

import com.resort.beachactivity.entity.Activity;
import com.resort.beachactivity.entity.Booking;
import com.resort.beachactivity.repository.ActivityRepository;
import com.resort.beachactivity.repository.BookingRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bookings")
public class BookingController {

    private final BookingRepository bookingRepository;
    private final ActivityRepository activityRepository;

    public BookingController(BookingRepository bookingRepository, ActivityRepository activityRepository) {
        this.bookingRepository = bookingRepository;
        this.activityRepository = activityRepository;
    }

    @GetMapping
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @GetMapping("/{id}")
    public Booking getBookingById(@PathVariable Long id) {
        return bookingRepository.findById(id).orElseThrow();
    }

    @PostMapping("/activity/{activityId}")
    public Booking addBookingToActivity(@PathVariable Long activityId, @RequestBody Booking booking) {
        Activity activity = activityRepository.findById(activityId).orElseThrow();
        activity.addBooking(booking);
        activityRepository.save(activity);
        return booking;
    }
}
