package com.resort.beachactivity.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String guestName;
    private LocalDate activityDate;
    private int numParticipants;

    @ManyToOne
    @JoinColumn(name = "activity_id")
    @JsonBackReference // Option 1: Use @JsonManagedReference and @JsonBackReference
    //@JsonIgnore  // Option 2: Use @JsonIgnore (Could be used only on one side of the relationship)
    private Activity activity;

    public Booking() {}

    public Booking(String guestName, LocalDate activityDate, int numParticipants) {
        this.guestName = guestName;
        this.activityDate = activityDate;
        this.numParticipants = numParticipants;
    }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getGuestName() { return guestName; }
    public void setGuestName(String guestName) { this.guestName = guestName; }

    public LocalDate getActivityDate() { return activityDate; }
    public void setActivityDate(LocalDate activityDate) { this.activityDate = activityDate; }

    public int getNumParticipants() { return numParticipants; }
    public void setNumParticipants(int numParticipants) { this.numParticipants = numParticipants; }

    public Activity getActivity() { return activity; }
    public void setActivity(Activity activity) { this.activity = activity; }
}
