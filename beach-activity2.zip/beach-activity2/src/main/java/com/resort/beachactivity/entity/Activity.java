package com.resort.beachactivity.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Activity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String category;
    private BigDecimal price;
    private int durationMinutes;

    @OneToMany(mappedBy = "activity", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference // Option 1: Use @JsonManagedReference and @JsonBackReference
    //@JsonIgnore  // Option 2: Use @JsonIgnore (Could be used only on one side of the relationship)
    private List<Booking> bookings = new ArrayList<>();

    public Activity() {}

    public Activity(String name, String category, BigDecimal price, int durationMinutes) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.durationMinutes = durationMinutes;
    }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }

    public int getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(int durationMinutes) { this.durationMinutes = durationMinutes; }

    public List<Booking> getBookings() { return bookings; }
    public void setBookings(List<Booking> bookings) { this.bookings = bookings; }

    public void addBooking(Booking booking) {
        bookings.add(booking);
        booking.setActivity(this);
    }

    public void removeBooking(Booking booking) {
        bookings.remove(booking);
        booking.setActivity(null);
    }
}
