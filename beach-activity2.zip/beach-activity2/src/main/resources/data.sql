-- Activities offered at Paradise Beach
INSERT INTO ACTIVITY (name, category, price, duration_minutes) VALUES
('Snorkeling Adventure', 'Water Sports', 45.00, 90),
('Sunset Yoga', 'Wellness', 30.00, 75),
('Beach Volleyball', 'Sports', 20.00, 60),
('Jet Ski Ride', 'Water Sports', 60.00, 30),
('Stand-Up Paddleboard', 'Water Sports', 35.00, 45),
('Sandcastle Workshop', 'Family Fun', 15.00, 40);

-- Bookings for some activities
INSERT INTO BOOKING (guest_name, activity_date, num_participants, activity_id) VALUES
('Sophia Wave', CURRENT_DATE, 2, 1),   -- Snorkeling Adventure
('James Coral', CURRENT_DATE, 4, 1),   -- Snorkeling Adventure
('Luna Breeze', CURRENT_DATE, 1, 2),   -- Sunset Yoga
('Mason Reef', CURRENT_DATE, 6, 3);    -- Beach Volleyball
