package org.example;

public class Main {
    public static void main(String[] args) {

        Calculator calculator = new Calculator();

        System.out.println(calculator.divide(10,5));
        System.out.println(calculator.divide(30,6));
        //System.out.println(calculator.divide(10,0)); // Not great to get an ArithmaticException at runtime
    }
}