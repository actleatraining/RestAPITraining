package org.example;

public class Calculator {
    public int divide(int a, int b) {
        return a / b;
    }
}
