INSERT INTO DRINK (name, size, price) VALUES
('Tropical Breeze Smoothie', 'Medium', 5.50),
('Coconut Dream', 'Large', 6.00),
('Mango Tango', 'Small', 4.50),
('Iced Cappuccino', 'Medium', 4.00),
('Espresso Shot', 'Small', 2.50),
('Pineapple Paradise', 'Large', 6.50);
