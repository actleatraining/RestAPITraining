package com.resort.smoothiebar.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
public class Drink {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String size;
    private BigDecimal price;

    public Drink() {
    }

    public Drink(String name, String size, BigDecimal price, String category) {
        this.name = name;
        this.size = size;
        this.price = price;
    }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }

    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }
}
