package com.resort.smoothiebar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmoothieBarApplicationTests {

	@Test
	void contextLoads() {
	}

}
