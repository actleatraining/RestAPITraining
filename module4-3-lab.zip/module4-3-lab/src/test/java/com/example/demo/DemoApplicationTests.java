package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import com.example.demo.model.Task;
import com.example.demo.repository.TaskRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
@Transactional
class DemoApplicationTests {

    @Autowired
    private TaskRepository repository;

    @Test
    void testFindAll() {
        List<Task> tasks = repository.findAll();
        assertThat(tasks).hasSize(3);
    }

    @Test
    void testFindById() {
        Optional<Task> t = repository.findById(2L);
        assertThat(t).isPresent();
        assertThat(t.get().getTitle()).isEqualTo("Write REST API");
    }

    @Test
    void testCreate() {
        Task t = new Task("New Task", false);
        Task saved = repository.save(t);

        assertThat(saved.getId()).isNotNull();
        assertThat(saved.getTitle()).isEqualTo("New Task");
    }

    @Test
    void testUpdate() {
        Task t = repository.findById(1L).orElseThrow();
        t.setCompleted(true);
        Task saved = repository.save(t);

        assertThat(saved.isCompleted()).isTrue();
    }

    @Test
    void testDelete() {
        repository.deleteById(3L);
        assertThat(repository.findById(3L)).isNotPresent();
    }
}

