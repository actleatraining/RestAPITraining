package com.example.demo;

import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TaskApiRestAssuredTest {

    @LocalServerPort
    private int port;

    @BeforeEach
    void setup() {
        RestAssured.port = port;
    }

    @Test
    void testGetAllTasks() {
        given()
                .when()
                .get("/tasks")
                .then()
                .statusCode(200)
                .body("$.size()", greaterThan(0));
    }

    @Test
    void testGetTaskById() {
        given()
                .when()
                .get("/tasks/1")
                .then()
                .statusCode(anyOf(is(200), is(404))); // depends on whether data.sql contains task 1
    }

    @Test
    void testCreateTask() {
        String json = """
        {
            "title": "Write Rest Assured Lab",
            "completed": false
        }
        """;

        given()
                .header("Content-Type", "application/json")
                .body(json)
                .when()
                .post("/tasks")
                .then()
                .statusCode(201)
                .body("id", notNullValue())
                .body("title", equalTo("Write Rest Assured Lab"))
                .body("completed", is(false));
    }

    @Test
    void testToggleTaskCompletion() {
        // First create a task
        int id =
                given()
                        .contentType("application/json")
                        .body("""
                    { "title": "Toggle me", "completed": false }
                """)
                        .when()
                        .post("/tasks")
                        .then()
                        .statusCode(201)
                        .extract()
                        .path("id");

        // Then toggle its status
        given()
                .when()
                .patch("/tasks/" + id + "/toggle")
                .then()
                .statusCode(200)
                .body("completed", is(true));
    }

    @Test
    void testDeleteTask() {
        // First create a task
        int id =
                given()
                        .contentType("application/json")
                        .body("""
                    { "title": "Delete me", "completed": false }
                """)
                        .when()
                        .post("/tasks")
                        .then()
                        .statusCode(201)
                        .extract()
                        .path("id");

        // Delete it
        given()
                .when()
                .delete("/tasks/" + id)
                .then()
                .statusCode(204);

        // Verify it's gone
        given()
                .when()
                .get("/tasks/" + id)
                .then()
                .statusCode(404);
    }
}

