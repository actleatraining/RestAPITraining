INSERT INTO TASK (title, completed) VALUES ('Learn Spring Boot', false);
INSERT INTO TASK (title, completed) VALUES ('Write REST API', true);
INSERT INTO TASK (title, completed) VALUES ('Test repository layer', false);
