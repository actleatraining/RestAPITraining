package com.example.demo.controller;

import com.example.demo.model.Person;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;

@RestController
@RequestMapping("/api/persons")
public class PersonController {

    private List<Person> persons = new ArrayList<>();

    public PersonController() {
        persons.add(new Person(1, "Alice", 30));
        persons.add(new Person(2, "Bob", 25));
    }

    @GetMapping
    public List<Person> getAll() {
        return persons;
    }

    @GetMapping("/{id}")
    public Person getOne(@PathVariable int id) {
        return persons.stream()
                .filter(p -> p.getId() == id)
                .findFirst()
                .orElse(null);
    }

    @PostMapping
    public Person create(@RequestBody Person person) {
        int newId = persons.size() + 1;
        person.setId(newId);
        persons.add(person);
        return person;
    }

    @PatchMapping("/{id}/increase-age")
    public Person increaseAge(@PathVariable int id) {
        Person p = persons.stream()
                .filter(x -> x.getId() == id)
                .findFirst()
                .orElse(null);

        if (p != null) {
            p.setAge(p.getAge() + 1);
        }

        return p;
    }
}

