package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/greeting")
public class GreetingController {

    // Simple text response
    @GetMapping
    public String sayHello() {
        return "Hello from Spring Boot!";
    }

    // Using @RequestParam
    // Example: /api/greeting/welcome?name=Alice
    @GetMapping("/welcome")
    public String welcome(@RequestParam String name) {
        return "Welcome, " + name + "!";
    }

    // Using @PathVariable
    // Example: /api/greeting/hello/Alice
    @GetMapping("/hello/{username}")
    public String greetUser(@PathVariable String username) {
        return "Hello " + username + "!";
    }
}

