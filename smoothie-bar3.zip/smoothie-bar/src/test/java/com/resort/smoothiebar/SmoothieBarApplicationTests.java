package com.resort.smoothiebar;

import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class SmoothieBarApplicationTests {

    @LocalServerPort
    private int port;

    @BeforeEach
    void setup() {
        RestAssured.port = port;
    }

    @Test
    void testValidateNestedDrinkObjects() {
        given()
                .when()
                .get("/categories")
                .then()
                .statusCode(200)
                // Validate first category
                .body("[0].name", equalTo("Smoothie"))
                .body("[0].drinks.size()", equalTo(4))
                .body("[0].drinks.name", hasItems(
                        "Tropical Breeze Smoothie",
                        "Coconut Dream",
                        "Mango Tango"
                ))
                // Validate fields deep inside JSON structure
                .body("[0].drinks[0].size", equalTo("Medium"))
                .body("[0].drinks[0].price", equalTo(5.5f))
                .body("[0].drinks[1].price", equalTo(6.0f))

                // Validate second category
                .body("[1].name", equalTo("Coffee"))
                .body("[1].drinks.size()", equalTo(2))
                .body("[1].drinks.name", hasItem("Iced Cappuccino"))
                .body("[1].drinks[1].name", equalTo("Espresso Shot"));
    }

    @Test
    void testExtractCategoryIdAndGetDetails() {
        int smoothieId =
                given()
                        .when()
                        .get("/categories")
                        .then()
                        .extract()
                        .path("[0].id");

        given()
                .when()
                .get("/categories/" + smoothieId)
                .then()
                .statusCode(200)
                .body("name", equalTo("Smoothie"))
                .body("drinks", hasSize(4))
                .body("drinks.name", hasItems(
                        "Tropical Breeze Smoothie",
                        "Pineapple Paradise"
                ));
    }

    @Test
    void testExtractNestedDrinkObjectsAsList() {
        List<Map<String, Object>> drinks =
                given()
                        .when()
                        .get("/categories")
                        .then()
                        .extract()
                        .path("[1].drinks");

        // Assertions using plain Java
        org.junit.jupiter.api.Assertions.assertEquals(2, drinks.size());
        org.junit.jupiter.api.Assertions.assertEquals("Iced Cappuccino", drinks.get(0).get("name"));
        org.junit.jupiter.api.Assertions.assertTrue(
                drinks.stream().anyMatch(d -> d.get("price").equals(2.5f))
        );
    }
}
