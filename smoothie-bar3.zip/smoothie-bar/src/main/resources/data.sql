-- Categories
INSERT INTO CATEGORY (name, description) VALUES
('Smoothie', 'Freshly blended tropical smoothies'),
('Coffee', 'Hot and iced espresso-based beverages');

-- Drinks (same as before, but with category references)
INSERT INTO DRINK (name, size, price, category_id) VALUES
('Tropical Breeze Smoothie', 'Medium', 5.50, 1),
('Coconut Dream', 'Large', 6.00, 1),
('Mango Tango', 'Small', 4.50, 1),
('Iced Cappuccino', 'Medium', 4.00, 2),
('Espresso Shot', 'Small', 2.50, 2),
('Pineapple Paradise', 'Large', 6.50, 1);
