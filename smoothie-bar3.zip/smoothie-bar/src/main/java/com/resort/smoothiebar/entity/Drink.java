package com.resort.smoothiebar.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
public class Drink {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String size;
    private BigDecimal price;

    @ManyToOne
    @JoinColumn(name = "category_id")
    @JsonBackReference // Option 1: Use @JsonManagedReference and @JsonBackReference
    //@JsonIgnore  // Option 2: Use @JsonIgnore (Could be used only on one side of the relationship)
    private Category category;

    public Drink() {}

    public Drink(String name, String size, BigDecimal price) {
        this.name = name;
        this.size = size;
        this.price = price;
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }

    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }
}
