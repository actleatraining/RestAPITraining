package com.resort.smoothiebar.repository;

import com.resort.smoothiebar.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Long> {}
