package com.example.demo;

import com.example.demo.model.Task;
import com.example.demo.service.TaskService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    void setUp() {
        service = new TaskService();
    }

    @Test
    void getAll_returnsInitialTasks() {
        List<Task> tasks = service.getAll();

        assertEquals(2, tasks.size());
        assertEquals("Buy milk", tasks.get(0).getTitle());
    }

    @Test
    void getById_returnsCorrectTask() {
        Task t = service.getById(1);

        assertNotNull(t);
        assertEquals("Buy milk", t.getTitle());
    }

    @Test
    void getById_returnsNullForInvalidId() {
        Task t = service.getById(999);
        assertNull(t);
    }

    @Test
    void create_addsNewTaskWithIncrementedId() {
        Task newTask = new Task(0, "Clean room", false);
        Task created = service.create(newTask);

        assertEquals(3, created.getId());
        assertEquals("Clean room", created.getTitle());

        assertEquals(3, service.getAll().size());
    }

    @Test
    void toggleComplete_flipsTheBoolean() {
        Task before = service.getById(1);
        boolean original = before.isCompleted();

        Task updated = service.toggleComplete(1);
        assertEquals(!original, updated.isCompleted());

        // Call again to verify it flips back
        Task updatedAgain = service.toggleComplete(1);
        assertEquals(original, updatedAgain.isCompleted());
    }

    // Optional challenge solution
    @Test
    void create_multipleTasksHaveSequentialIds() {
        Task t1 = service.create(new Task(0, "A", false));
        Task t2 = service.create(new Task(0, "B", false));
        Task t3 = service.create(new Task(0, "C", false));

        assertEquals(3, t1.getId());
        assertEquals(4, t2.getId());
        assertEquals(5, t3.getId());
    }
}

