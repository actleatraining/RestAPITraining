package com.example.demo.service;

import com.example.demo.model.Task;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TaskService {

    private List<Task> tasks = new ArrayList<>();
    private int nextId = 1;

    public TaskService() {
        tasks.add(new Task(nextId++, "Buy milk", false));
        tasks.add(new Task(nextId++, "Study Spring Boot", false));
    }

    // Return all tasks
    public List<Task> getAll() {
        return tasks;
    }

    // Return task by ID
    public Task getById(int id) {
        return tasks.stream()
                .filter(t -> t.getId() == id)
                .findFirst()
                .orElse(null);
    }

    // Create a new task
    public Task create(Task taskRequest) {
        Task task = new Task(nextId++, taskRequest.getTitle(), false);
        tasks.add(task);
        return task;
    }

    // Toggle completion status
    public Task toggleComplete(int id) {
        Task task = getById(id);
        if (task != null) {
            task.setCompleted(!task.isCompleted());
        }
        return task;
    }
}

