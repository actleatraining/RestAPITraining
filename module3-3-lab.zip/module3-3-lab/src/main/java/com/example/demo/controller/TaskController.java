package com.example.demo.controller;

import com.example.demo.model.Task;
import com.example.demo.service.TaskService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private final TaskService taskService;

    // Constructor injection
    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    // GET /api/tasks
    @GetMapping
    public List<Task> getAll() {
        return taskService.getAll();
    }

    // GET /api/tasks/{id}
    @GetMapping("/{id}")
    public Task getOne(@PathVariable int id) {
        return taskService.getById(id);
    }

    // POST /api/tasks
    @PostMapping
    public Task create(@RequestBody Task taskRequest) {
        return taskService.create(taskRequest);
    }

    // PATCH /api/tasks/{id}/toggle
    @PatchMapping("/{id}/toggle")
    public Task toggle(@PathVariable int id) {
        return taskService.toggleComplete(id);
    }
}
