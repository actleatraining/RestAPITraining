-- Activities offered at Paradise Beach
INSERT INTO ACTIVITY (name, category, price, duration_minutes) VALUES
('Snorkeling Adventure', 'Water Sports', 45.00, 90),
('Sunset Yoga', 'Wellness', 30.00, 75),
('Beach Volleyball', 'Sports', 20.00, 60),
('Jet Ski Ride', 'Water Sports', 60.00, 30),
('Stand-Up Paddleboard', 'Water Sports', 35.00, 45),
('Sandcastle Workshop', 'Family Fun', 15.00, 40);
