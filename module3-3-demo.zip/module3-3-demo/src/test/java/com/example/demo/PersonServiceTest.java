package com.example.demo;

import com.example.demo.model.Person;
import com.example.demo.service.PersonService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PersonServiceTest {

    private PersonService service;

    @BeforeEach
    void setUp() {
        service = new PersonService();
    }

    @Test
    void getAll_returnsInitialPersons() {
        List<Person> persons = service.getAll();
        assertEquals(2, persons.size());
        assertEquals("Alice", persons.get(0).getName());
    }

    @Test
    void getById_returnsCorrectPerson() {
        Person p = service.getById(1);
        assertNotNull(p);
        assertEquals("Alice", p.getName());
    }

    @Test
    void getById_returnsNullForUnknownId() {
        Person p = service.getById(999);
        assertNull(p);
    }

    @Test
    void create_addsNewPersonWithIncrementedId() {
        Person p = new Person(0, "Charlie", 40);

        Person created = service.create(p);

        assertEquals(3, created.getId());
        assertEquals("Charlie", created.getName());
        assertEquals(3, service.getAll().size());
    }

    @Test
    void increaseAge_incrementsAgeByOne() {
        Person p = service.increaseAge(1);

        assertNotNull(p);
        assertEquals(31, p.getAge());
    }
}

