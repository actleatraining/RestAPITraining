package com.example.demo.service;

import com.example.demo.model.Person;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class PersonService {

    private List<Person> persons = new ArrayList<>();

    public PersonService() {
        persons.add(new Person(1, "Alice", 30));
        persons.add(new Person(2, "Bob", 25));
    }

    public List<Person> getAll() {
        return persons;
    }

    public Person getById(int id) {
        return persons.stream()
                .filter(p -> p.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public Person create(Person p) {
        int newId = persons.size() + 1;
        p.setId(newId);
        persons.add(p);
        return p;
    }

    public Person increaseAge(int id) {
        Person p = getById(id);
        if (p != null) {
            p.setAge(p.getAge() + 1);
        }
        return p;
    }
}

