package com.example.demo.controller;

import com.example.demo.model.Person;
import com.example.demo.service.PersonService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/persons")
public class PersonController {

    private final PersonService service;

    public PersonController(PersonService service) {
        this.service = service; // Spring injects this dependency
    }

    @GetMapping
    public List<Person> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public Person getOne(@PathVariable int id) {
        return service.getById(id);
    }

    @PostMapping
    public Person create(@RequestBody Person p) {
        return service.create(p);
    }

    @PatchMapping("/{id}/increase-age")
    public Person increaseAge(@PathVariable int id) {
        return service.increaseAge(id);
    }
}

