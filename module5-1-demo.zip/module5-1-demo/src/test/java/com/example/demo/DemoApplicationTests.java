package com.example.demo;

import com.example.demo.model.Person;
import com.example.demo.repository.PersonRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@Transactional
class DemoApplicationTests {

	@Test
	void contextLoads() {
	}

    @Autowired
    private PersonRepository repository;

    @Test
    void testFindAll() {
        List<Person> persons = repository.findAll();
        assertThat(persons).hasSize(3); // Alice, Bob, Charlie from data.sql
    }

    @Test
    void testFindById() {
        Optional<Person> result = repository.findById(1L);
        assertThat(result).isPresent();
        assertThat(result.get().getName()).isEqualTo("Alice");
    }

    @Test
    void testCreatePerson() {
        Person p = new Person("Diana", 22);
        Person saved = repository.save(p);

        assertThat(saved.getId()).isNotNull();
        assertThat(saved.getName()).isEqualTo("Diana");
        assertThat(saved.getAge()).isEqualTo(22);

        // Verify it exists in DB
        assertThat(repository.findById(saved.getId())).isPresent();
    }

    @Test
    void testUpdatePerson() {
        Person existing = repository.findById(2L).orElseThrow(); // Bob
        Person updated = new Person(existing.getId(), "Bob Updated", 26);

        Person saved = repository.save(updated);

        assertThat(saved.getName()).isEqualTo("Bob Updated");
        assertThat(saved.getAge()).isEqualTo(26);

        // Verify stored value
        Person reloaded = repository.findById(2L).orElseThrow();
        assertThat(reloaded.getAge()).isEqualTo(26);
    }

    @Test
    void testDeletePerson() {
        repository.deleteById(3L); // Charlie

        assertThat(repository.findById(3L)).isNotPresent();
        assertThat(repository.findAll()).hasSize(2);
    }
}
