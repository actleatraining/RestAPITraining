package com.example.demo;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import static org.hamcrest.Matchers.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class PersonApiRestAssuredTest {

    @LocalServerPort
    private int port;

    @BeforeEach
    void setup() {
        RestAssured.port = port;
    }

    @Test
    void getAllPersons_shouldReturnList() {
        RestAssured
                .given()
                .when()
                .get("/persons")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .body("$.size()", greaterThan(0)); // $.size() is a JSON path expression used by Rest Assured to check the size of the top-level JSON array returned by the API.
    }

    @Test
    void getPersonById_shouldReturnCorrectPerson() {
        RestAssured
                .given()
                .when()
                .get("/persons/1")
                .then()
                .statusCode(200)
                .body("id", equalTo(1))
                .body("name", notNullValue())
                .body("age", greaterThan(0));
    }

    @Test
    void createPerson_shouldReturnCreatedPerson() {
        String json = """
            {
                "name": "New Person",
                "age": 40
            }
            """;

        RestAssured
                .given()
                .contentType("application/json")
                .body(json)
                .when()
                .post("/persons")
                .then()
                .statusCode(201)
                .body("id", notNullValue())
                .body("name", equalTo("New Person"))
                .body("age", equalTo(40));
    }

    @Test
    void testDeletePerson() {
        // First create a person
        int id =
                RestAssured.
                given()
                        .contentType("application/json")
                        .body("""
                        { "name": "John Doe", "age": 30 }
                    """)
                        .when()
                        .post("/persons")
                        .then()
                        .statusCode(201)
                        .extract()
                        .path("id");

        // Delete the person
        RestAssured.
        given()
                .when()
                .delete("/persons/" + id)
                .then()
                .statusCode(204);

        // Verify the person is gone
        RestAssured.
        given()
                .when()
                .get("/persons/" + id)
                .then()
                .statusCode(404);
    }

    // ---------------------------------------------------------
    // NEW NEGATIVE TESTS FROM MODULE 5-1
    // ---------------------------------------------------------

    @Test
    void getNonExistingPerson_shouldReturn404() {
        RestAssured.given()
                .when()
                .get("/persons/9999")
                .then()
                .statusCode(404);
    }

    @Test
    void deleteNonExistingPerson_shouldReturn404() {
        RestAssured.given()
                .when()
                .delete("/persons/9999")
                .then()
                .statusCode(404);
    }

    @Test
    void createPerson_missingName_shouldReturn400() {
        String json = """
            {
                "name": "",
                "age": 30
            }
            """;

        RestAssured.given()
                .contentType("application/json")
                .body(json)
                .when()
                .post("/persons")
                .then()
                .statusCode(400);
    }

    @Test
    void createPerson_negativeAge_shouldReturn400() {
        String json = """
            {
                "name": "Bad Age",
                "age": -5
            }
            """;

        RestAssured.given()
                .contentType("application/json")
                .body(json)
                .when()
                .post("/persons")
                .then()
                .statusCode(400);
    }

}

