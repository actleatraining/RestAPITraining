INSERT INTO PERSON (name, age) VALUES ('Alice', 30);
INSERT INTO PERSON (name, age) VALUES ('Bob', 25);
INSERT INTO PERSON (name, age) VALUES ('Charlie', 40);
