package com.example.demo;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import static org.hamcrest.Matchers.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class PersonApiRestAssuredTest {

    @LocalServerPort
    private int port;

    @BeforeEach
    void setup() {
        RestAssured.port = port;
    }

    @Test
    void getAllPersons_shouldReturnList() {
        RestAssured
                .given()
                .when()
                .get("/persons")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .body("$.size()", greaterThan(0)); // $.size() is a JSON path expression used by Rest Assured to check the size of the top-level JSON array returned by the API.
    }

    @Test
    void getPersonById_shouldReturnCorrectPerson() {
        RestAssured
                .given()
                .when()
                .get("/persons/1")
                .then()
                .statusCode(200)
                .body("id", equalTo(1))
                .body("name", notNullValue())
                .body("age", greaterThan(0));
    }

    @Test
    void createPerson_shouldReturnCreatedPerson() {
        String json = """
            {
                "name": "New Person",
                "age": 40
            }
            """;

        RestAssured
                .given()
                .contentType("application/json")
                .body(json)
                .when()
                .post("/persons")
                .then()
                .statusCode(201)
                .body("id", notNullValue())
                .body("name", equalTo("New Person"))
                .body("age", equalTo(40));
    }
}

