package org.example;

public class Calculator {
    public double power(int base, int exponent) {
        // Minimal implementation for TDD Green step
        return Math.pow(base, exponent);
    }
}
