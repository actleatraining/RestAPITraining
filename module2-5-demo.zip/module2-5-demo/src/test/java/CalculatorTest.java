import org.example.Calculator;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CalculatorTest {

    @Test
    void testPowerPositiveExponent() {
        Calculator calculator = new Calculator();
        double result = calculator.power(2, 3);
        assertEquals(8.0, result, 0.0001);
    }

    @Test
    void testPowerZeroExponent() {
        Calculator calculator = new Calculator();
        double result = calculator.power(5, 0);
        assertEquals(1.0, result, 0.0001);
    }

    @Test
    void testPowerNegativeExponent() {
        Calculator calculator = new Calculator();
        double result = calculator.power(2, -1);
        assertEquals(0.5, result, 0.0001);
    }
}
