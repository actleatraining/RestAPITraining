
import org.example.Calculator;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {

    private Calculator calculator;

    @BeforeEach
    void setUp() {
        calculator = new Calculator();
    }

    // ---- Modulus ----
    @Test
    void testModulusPositiveNumbers() {
        assertEquals(1, calculator.modulus(10, 3));
    }

    @Test
    void testModulusNegativeNumbers() {
        assertEquals(-1, calculator.modulus(-10, 3));
    }

    @Test
    void testModulusByZeroThrowsException() {
        Exception ex = assertThrows(IllegalArgumentException.class, () -> calculator.modulus(10, 0));
        assertEquals("Cannot perform modulus by zero", ex.getMessage());
    }

    // ---- isEven ----
    @ParameterizedTest
    @CsvSource({
            "2, true",
            "3, false",
            "1022, true",
            "11, false"
    })
    void testIsEven(int number, boolean expected) {
        assertEquals(expected, calculator.isEven(number));
    }

    // ---- absolute ----
    @Test
    void testAbsolutePositiveNumber() {
        assertEquals(5, calculator.absolute(5));
    }

    @Test
    void testAbsoluteNegativeNumber() {
        assertEquals(5, calculator.absolute(-5));
    }

    @Test
    void testAbsoluteZero() {
        assertEquals(0, calculator.absolute(0));
    }
}

