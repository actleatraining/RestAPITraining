package org.example;

public class Calculator {
    public int modulus(int a, int b) {
        if (b == 0) {
            throw new IllegalArgumentException("Cannot perform modulus by zero");
        }
        return a % b;
    }

    public boolean isEven(int number) {
        return number % 2 == 0;
    }

    public int absolute(int number) {
        return number < 0 ? -number : number;
    }
}
