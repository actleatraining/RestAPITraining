
import org.example.Calculator;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {

    private Calculator calculator;

    @BeforeEach
    void setUp() {
        calculator = new Calculator();
        System.out.println("Starting new test...");
    }

    @AfterEach
    void tearDown() {
        System.out.println("Test finished.");
    }

    @Test
    void testAddition() {
        int result = calculator.add(10, 5);
        assertEquals(15, result, "Addition should return the sum of two numbers");
    }

    @Test
    void testSubtraction() {
        int result = calculator.subtract(10, 5);
        assertEquals(5, result, "Subtraction should return the difference between two numbers");
    }

    @Test
    void testMultiplication() {
        int result = calculator.multiply(10, 5);
        assertEquals(50, result, "Multiplication should return the product of two numbers");
    }

    @Test
    void testDivision() {
        double result = calculator.divide(10, 2);
        assertEquals(5.0, result, 0.0001, "Division should return the quotient");
    }

    @Test
    void testDivisionByZeroThrowsException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> calculator.divide(10, 0));
        assertEquals("Cannot divide by zero", exception.getMessage());
    }
}

