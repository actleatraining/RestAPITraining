import org.example.Calculator;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CalculatorTest2 {

    Calculator calculator;

    @BeforeEach
    void setUp() {
        calculator = new Calculator();
        System.out.println("Starting test...");
    }

    @AfterEach
    void tearDown() {
        System.out.println("Finished test.");
    }

    @Test
    public void testDivision() {
        //Calculator calculator = new Calculator();
        Assertions.assertEquals(2, calculator.divide(10,5));
        Assertions.assertEquals(3, calculator.divide(6,2));
        Assertions.assertEquals(4, calculator.divide(32,8));
    }

    @Test
    public void testDivisionByZero() {
        //Calculator calculator = new Calculator();
        Assertions.assertThrows(ArithmeticException.class, () -> calculator.divide(10, 0));
    }
}
