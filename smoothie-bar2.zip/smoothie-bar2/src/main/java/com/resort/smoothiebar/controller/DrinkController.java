package com.resort.smoothiebar.controller;

import com.resort.smoothiebar.entity.Drink;
import com.resort.smoothiebar.repository.DrinkRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/drinks")
public class DrinkController {

    private final DrinkRepository drinkRepository;

    public DrinkController(DrinkRepository drinkRepository) {
        this.drinkRepository = drinkRepository;
    }

    @GetMapping
    public List<Drink> getAllDrinks() {
        return drinkRepository.findAll();
    }

    @GetMapping("/{id}")
    public Drink getDrinkById(@PathVariable Long id) {
        return drinkRepository.findById(id).orElseThrow();
    }

    @PostMapping
    public Drink createDrink(@RequestBody Drink drink) {
        return drinkRepository.save(drink);
    }

    @PutMapping("/{id}")
    public Drink updateDrink(@PathVariable Long id, @RequestBody Drink drink) {
        Drink existing = drinkRepository.findById(id).orElseThrow();
        existing.setName(drink.getName());
        existing.setSize(drink.getSize());
        existing.setPrice(drink.getPrice());
        existing.setCategory(drink.getCategory());
        return drinkRepository.save(existing);
    }

    @DeleteMapping("/{id}")
    public void deleteDrink(@PathVariable Long id) {
        drinkRepository.deleteById(id);
    }
}

