package com.resort.beachactivity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeachActivityApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeachActivityApplication.class, args);
	}

}
